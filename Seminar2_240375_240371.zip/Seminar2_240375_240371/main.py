from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import subprocess
from pathlib import Path
import json

# Creamos la app de FastAPI
app = FastAPI()


# EJERCICIO 1
# Definimos el modelo para poner los datos
class VideoResizeRequest(BaseModel):
    width: int  # Anchura del video
    height: int  # Altura del video
    file_path: str  # Ruta del archivo donde tengamos guardado el video 'big buck bunny'

@app.post("/EJERCICIO 1/")
async def resize_video(request: VideoResizeRequest):
    input_path = Path(request.file_path).resolve()
    print(f"Ruta del archivo: {input_path}")
    output_path = input_path.parent / "output_video_bbb.mp4"

    # Definimos el comando de FFmpeg para redimensionar el video
    ffmpeg_command = [
        "ffmpeg",  # Comando para ejecutar FFmpeg
        "-i", str(input_path),  # Archivo de entrada
        "-vf", f"scale={request.width}:{request.height}",  # Filtro para redimensionar
        "-c:v", "libx264",  # Usamos el codec de video h.264
        "-crf", "23",  # Calidad del video
        "-preset", "veryfast",  # Velocidad de codificación
        str(output_path)  # Ruta de salida
    ]

    # Ejecutamos el comando FFmpeg
    process = subprocess.run(
        ffmpeg_command,
        stdout=subprocess.PIPE,  # Capturamos la salida estándar
            stderr=subprocess.PIPE,  # Capturamos los errores
            text=True
        )

    # Si funciona, devolvemos mensaje
    return {"message": "Video redimensionado correctamente.", "output_path": str(output_path)}

# EJERCICIO 2
# Modelo para cambiar el chroma subsampling
class ChromaChangeRequest(BaseModel):
    chroma_format: str  # Formato de chroma subsampling (ejemplo: yuv420p, yuv422p, yuv444p)
    file_path: str  # Ruta del archivo de video a procesar

@app.post("/EJERCICIO 2/")
async def change_chroma(request: ChromaChangeRequest):
    input_path = Path(request.file_path).resolve()
    output_path = input_path.parent / "output_chroma.mp4"

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="El archivo de entrada no existe.")

    # Definimos el comando que ejecuta FFmpeg para cambiar el chroma subsampling
    ffmpeg_command = [
        "ffmpeg",
        "-y",                          # Sobrescribe el archivo de salida si ya existe
        "-i", str(input_path),         # Especificamos el archivo de entrada
        "-pix_fmt", "yuv420p",         # Establecemos el formato de subsampling de chroma
        "-c:v", "libx264",             # Usamos el códec H.264 para el video
        "-crf", "23",                  # Configuramos la calidad del video
        "-preset", "medium",           # Elegimos un preset equilibrado entre calidad y velocidad
        "-c:a", "aac",                 # Usamos el códec AAC para el audio
        "-movflags", "faststart",      # Optimización para que el archivo sea adecuado para streaming
        str(output_path)
    ]

    try:
        # Ejecutamos el comando de FFmpeg
        process = subprocess.run(
            ffmpeg_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        if process.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"Error de FFmpeg: {process.stderr.strip()}"
            )

    except Exception as e:
        # Si ocurre un error
        raise HTTPException(status_code=500, detail=str(e))

    return {"message": "Chroma subsampling modificado.", "output_path": str(output_path)}

# EJERCICIO 3
# Modelo para recibir la ruta del archivo
class VideoInfoRequest(BaseModel):
    file_path: str = Field(..., description="Ruta al archivo de video.")

@app.post("/EJERCICIO 3/")
async def get_video_info(request: VideoInfoRequest):
    input_path = Path(request.file_path).resolve()

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="El archivo de entrada no existe.")

    # Comando FFmpeg para obtener información sobre el video
    ffmpeg_command = [
        "ffmpeg",
        "-i", str(input_path),
        "-hide_banner"  # Esta opción reduce la salida innecesaria
    ]

    try:
        # Ejecutamos el comando de FFmpeg
        process = subprocess.run(
            ffmpeg_command,
            stderr=subprocess.PIPE,  # FFmpeg imprime la info relevante en stderr
            stdout=subprocess.PIPE,  # Ignoramos stdout aquí
            text=True
        )

        # Capturamos la salida de errores porque FFmpeg pone la información allí
        ffmpeg_output = process.stderr

        # Extraemos información clave del video
        video_info = {}
        for line in ffmpeg_output.splitlines():
            if "Duration" in line:
                duration = line.split(",")[0].split("Duration: ")[1].strip()
                video_info["Duration"] = duration
            if "Stream" in line and "Video" in line:
                codec = line.split(":")[1].split(",")[0].strip()
                resolution = line.split(",")[2].strip()
                video_info["Video Codec"] = codec
                video_info["Resolution"] = resolution
            if "Stream" in line and "Audio" in line:
                audio_codec = line.split(":")[1].split(",")[0].strip()
                video_info["Audio Codec"] = audio_codec

        if not video_info:
            raise HTTPException(status_code=500, detail="No se pudo obtener información del video.")

    except Exception as e:
        # En caso de error
        raise HTTPException(status_code=500, detail=f"Error al procesar el video: {str(e)}")

    return {"message": "Información del video obtenida.", "video_info": video_info}

# EJERCICIO 4
# Modelo para recibir la ruta del archivo
class ContainerRequest(BaseModel):
    file_path: str = Field(..., description="Ruta al archivo de video.")

@app.post("/EJERCICIO 4/")
async def create_container(request: ContainerRequest):
    input_path = Path(request.file_path).resolve()
    output_dir = input_path.parent
    output_video = output_dir / "big_buck_bunny_20s.mp4"
    output_aac = output_dir / "audio_aac_mono.aac"
    output_mp3 = output_dir / "audio_mp3_stereo.mp3"
    output_ac3 = output_dir / "audio_ac3.ac3"
    final_container = output_dir / "big_buck_bunny_container.mp4"

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="El archivo de entrada no existe.")

    try:
        # Cortar el video a 20 segundos
        cut_command = [
            "ffmpeg",
            "-y",                         # Sobrescribir sin preguntar
            "-i", str(input_path),        # Archivo de entrada
            "-t", "20",                   # Duración (20 segundos)
            "-c:v", "copy",               # Copiar el video sin recodificar
            "-c:a", "copy",               # Copiar el audio sin recodificar
            str(output_video)             # Archivo de salida
        ]
        subprocess.run(cut_command, check=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

        # Exportar audio como AAC mono
        aac_command = [
            "ffmpeg",
            "-y",
            "-i", str(output_video),
            "-vn",                         # Sin video
            "-acodec", "aac",              # Códec AAC
            "-ac", "1",                    # Mono
            str(output_aac)
        ]
        subprocess.run(aac_command, check=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

        # Exportar audio como MP3
        mp3_command = [
            "ffmpeg",
            "-y",
            "-i", str(output_video),
            "-vn",
            "-acodec", "libmp3lame",       # Códec MP3
            "-ac", "2",                    # Estéreo
            "-b:a", "128k",                # Bitrate reducido
            str(output_mp3)
        ]
        subprocess.run(mp3_command, check=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

        # Exportar audio como AC3
        ac3_command = [
            "ffmpeg",
            "-y",
            "-i", str(output_video),
            "-vn",
            "-acodec", "ac3",              # Códec AC3
            str(output_ac3)
        ]
        subprocess.run(ac3_command, check=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

        # Empaquetar en nuevo .mp4
        container_command = [
            "ffmpeg",
            "-y",
            "-i", str(output_video),       # Video original
            "-i", str(output_aac),         # Pista de audio AAC
            "-i", str(output_mp3),         # Pista de audio MP3
            "-i", str(output_ac3),         # Pista de audio AC3
            "-map", "0:v:0",               # Mapear el video original
            "-map", "1:a:0",               # Mapear audio AAC
            "-map", "2:a:0",               # Mapear audio MP3
            "-map", "3:a:0",               # Mapear audio AC3
            "-c:v", "copy",                # Copiar video sin recodificar
            "-c:a", "copy",                # Copiar audio sin recodificar
            str(final_container)           # Contenedor final
        ]
        subprocess.run(container_command, check=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"Error de FFmpeg: {e.stderr}")

    return {
        "message": "Nuevo contenedor creado exitosamente.",
        "output_files": {
            "20s_video": str(output_video),
            "aac_audio": str(output_aac),
            "mp3_audio": str(output_mp3),
            "ac3_audio": str(output_ac3),
            "final_container": str(final_container)
        }
    }

# EJERCICIO 5
# Modelo para recibir la ruta del archivo
class TrackInfoRequest(BaseModel):
    file_path: str = Field(..., description="Ruta al contenedor MP4.")

@app.post("/EJERCICIO 5/")
async def count_tracks(request: TrackInfoRequest):
    input_path = Path(request.file_path).resolve()

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="El archivo de entrada no existe.")

    try:
        # Comando ffprobe para obtener información del contenedor en formato JSON
        ffprobe_command = [
            "ffprobe",
            "-v", "error",             # Mostrar solo errores
            "-print_format", "json",   # Salida en formato JSON
            "-show_streams",           # Mostrar información de las pistas
            str(input_path)
        ]

        # Ejecutamos el comando
        process = subprocess.run(
            ffprobe_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        if process.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"Error de FFprobe: {process.stderr.strip()}"
            )

        # Parseamos la salida JSON
        ffprobe_output = json.loads(process.stdout)

        # Contamos el número de pistas
        track_count = len(ffprobe_output.get("streams", []))

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "message": "Número de pistas obtenidas.",
        "track_count": track_count
    }

# EJERCICIO 6
# Modelo para recibir la ruta del archivo y el nombre del archivo de salida
class MacroblockMotionRequest(BaseModel):
    file_path: str = Field(..., description="Ruta al archivo de entrada (MP4).")
    output_name: str = Field(..., description="Nombre del archivo de salida.")

@app.post("/EJERCICIO 6/")
async def show_macroblocks_motion(request: MacroblockMotionRequest):
    input_path = Path(request.file_path).resolve()
    output_path = input_path.parent / request.output_name

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="El archivo de entrada no existe.")

    try:
        # Comando FFmpeg
        ffmpeg_command = [
            "ffmpeg",
            "-i", str(input_path),  # Video de entrada
            "-vf", "scale=640:360,codecview=mv=1",  # Escala y muestra los vectores de movimiento con codecview
            "-c:v", "libx264",  # Códec de video
            "-crf", "23",  # Calidad del video
            "-preset", "medium",  # Configuración de codificación
            "-c:a", "aac",  # Códec de audio
            "-movflags", "faststart",  # Optimización para streaming
            str(output_path)  # Ruta de salida
        ]

        # Ejecutamos el comando FFmpeg
        process = subprocess.run(
            ffmpeg_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Verificamos si hay algun error
        if process.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"Error de FFmpeg: {process.stderr.strip()}"
            )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "message": "Video con macrobloques y vectores de movimiento creado correctamente.",
        "output_path": str(output_path)
    }

# EJERCICIO 7
class YUVHistogramRequest(BaseModel):
    file_path: str
    output_name: str

@app.post("/EJERCICIO 7/")
async def show_yuv_histogram(request: YUVHistogramRequest):
    input_path = Path(request.file_path).resolve()
    output_path = input_path.parent / request.output_name

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="El archivo de entrada no existe.")

    try:
        # Comando FFmpeg para mostrar el histograma YUV
        ffmpeg_command = [
            "ffmpeg",
            "-i", str(input_path),                # Video de entrada
            "-vf", "histogram",                   # Filtro para el histograma YUV
            "-pix_fmt", "yuv420p",                # Aseguramos que el formato de píxeles sea compatible
            "-c:v", "libx264",                    # Códec de video (libx264)
            "-crf", "23",                         # Calidad de video
            "-preset", "medium",                  # Configuración de codificación
            "-c:a", "aac",                        # Códec de audio (AAC)
            "-b:a", "128k",                       # Bitrate del audio (AAC)
            "-movflags", "faststart",             # Optimización para streaming
            str(output_path)                      # Ruta de salida
        ]

        # Ejecutamos el comando FFmpeg
        process = subprocess.run(
            ffmpeg_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        if process.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"Error de FFmpeg: {process.stderr.strip()}"
            )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "message": "Video con histograma YUV creado.",
        "output_path": str(output_path)
    }

# Ruta para verificar que el servidor funciona
@app.get("/")
async def root():
    return {"message": "Todo va bien profe."}









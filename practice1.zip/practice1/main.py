import os
import tempfile
from fastapi import FastAPI, UploadFile, Form
from pydantic import BaseModel
import subprocess
import numpy as np
from scipy.fftpack import dct, idct
import pywt

# Instanciamos la aplicación FastAPI
app = FastAPI()

# Endpoint de bienvenida
@app.get("/")
def read_root():
    return {"message": "Bienvenido a la API de practice1"}


class ColorConverter:
    @staticmethod
    def rgb_to_yuv(r, g, b):
        y = round(0.299 * r + 0.587 * g + 0.114 * b, 2)
        u = round(-0.14713 * r - 0.28886 * g + 0.436 * b, 2)
        v = round(0.615 * r - 0.51499 * g - 0.10001 * b, 2)
        return y, u, v

    @staticmethod
    def yuv_to_rgb(y, u, v):
        r = round(y + 1.13983 * v, 2)
        g = round(y - 0.39465 * u - 0.58060 * v, 2)
        b = round(y + 2.03211 * u, 2)
        return r, g, b

# Modelos para los datos de entrada
class RGB(BaseModel):
    r: int
    g: int
    b: int

class YUV(BaseModel):
    y: float
    u: float
    v: float


# EJERCICIO 4. Endpoints para la conversión de colores
@app.post("/convert_rgb_to_yuv")
def convert_rgb_to_yuv(rgb: RGB):
    y, u, v = ColorConverter.rgb_to_yuv(rgb.r, rgb.g, rgb.b)
    return {"Y": y, "U": u, "V": v}

@app.post("/convert_yuv_to_rgb")
def convert_yuv_to_rgb(yuv: YUV):
    r, g, b = ColorConverter.yuv_to_rgb(yuv.y, yuv.u, yuv.v)
    return {"R": r, "G": g, "B": b}


class ImageProcessor:
    @staticmethod
    def resize_image(input_file, output_file, width, height, quality):
        """
        Redimensiona una imagen usando FFmpeg.
        Args:
            input_file (str): Ruta del archivo de entrada.
            output_file (str): Ruta del archivo de salida.
            width (int): Ancho de la imagen redimensionada.
            height (int): Altura de la imagen redimensionada.
            quality (int): Nivel de calidad (mayor = peor calidad).
        """
        command = [
            "ffmpeg", "-i", input_file,
            "-vf", f"scale={width}:{height}",
            "-q:v", str(quality),
            output_file
        ]
        subprocess.run(command, check=True)
        print(f"Image resized and saved as {output_file}")



class JPEGProcessor:
    @staticmethod
    def serpentine(file_path):
        """
        Lee los bytes de un archivo JPEG y los recorre en un patrón serpentino.
        Args:
            file_path (str): Ruta al archivo JPEG.
        Returns:
            list: Lista de bytes en orden serpentino.
        """
        # Abrir el archivo en modo binario y leer los datos
        with open(file_path, "rb") as file:
            data = file.read()


        # Crear una matriz ficticia para simular las filas (aquí usamos filas de 16 bytes por ejemplo)
        rows = [data[i:i+16] for i in range(0, len(data), 16)]


        # Recorrer en patrón serpentino
        serpentine_bytes = []
        for i, row in enumerate(rows):
            if i % 2 == 0:  # Fila normal (izquierda a derecha)
                serpentine_bytes.extend(row)
            else:  # Fila invertida (derecha a izquierda)
                serpentine_bytes.extend(row[::-1])

        return serpentine_bytes



class ImageProcessor:
    @staticmethod
    def compress_to_bw(input_file, output_file, compression_level):
        """
        Convierte una imagen a blanco y negro y la comprime.
        Args:
            input_file (str): Ruta del archivo de entrada.
            output_file (str): Ruta del archivo de salida.
            compression_level (int): Nivel de compresión (mayor = más compresión).
        """
        command = [
            "ffmpeg", "-i", input_file,
            "-vf", "format=gray",
            "-q:v", str(compression_level),
            output_file
        ]
        # Ejecuta el comando silenciando la salida
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


UPLOADS_DIR = "uploads"
if not os.path.exists(UPLOADS_DIR):
    os.makedirs(UPLOADS_DIR)

# EJERCICIO 4. Endpoint para compresión a blanco y negro
@app.post("/compress_to_bw")
async def compress_image_to_bw(file: UploadFile, compression_level: int = Form(...)):
    """
    Endpoint para convertir una imagen a blanco y negro y comprimirla.
    Args:
        file (UploadFile): Imagen a procesar.
        compression_level (int): Nivel de compresión.
    Returns:
        dict: Información sobre la imagen procesada.
    """
    try:
        # Guardar archivo temporal en la carpeta uploads
        input_path = os.path.join(UPLOADS_DIR, f"temp_{file.filename}")
        with open(input_path, "wb") as input_file:
            input_file.write(await file.read())

        # Definir archivo de salida en la carpeta uploads
        output_path = os.path.join(UPLOADS_DIR, f"compressed_bw_{file.filename}")

        # Procesar imagen
        ImageProcessor.compress_to_bw(input_path, output_path, compression_level)

        # Eliminar archivo temporal
        os.remove(input_path)

        return {"message": "Imagen procesada correctamente.", "output_file": output_path}
    except Exception as e:
        return {"error": str(e)}

class CompressionUtils:
    @staticmethod
    def run_length_encoding(byte_sequence):
        """
        Aplica el algoritmo Run-Length Encoding (RLE) sobre una secuencia de bytes.
        Args:
            byte_sequence (list): Lista de bytes a comprimir.
        Returns:
            list: Lista de tuplas (byte, repeticiones) que representan la secuencia comprimida.
        """
        encoded = []
        i = 0
        while i < len(byte_sequence):
            count = 1
            while i + 1 < len(byte_sequence) and byte_sequence[i] == byte_sequence[i + 1]:
                i += 1
                count += 1
            encoded.append((byte_sequence[i], count))
            i += 1
        return encoded



class DCTProcessor:
    def __init__(self, image_data):
        """
        Constructor que recibe los datos de la imagen (como un array 2D).
        """
        self.image_data = image_data


    def apply_dct(self):
        """
        Aplica la transformada discreta del coseno (DCT) a los datos de la imagen.
        Devuelve los coeficientes de la DCT en las direcciones de filas y columnas.
        """
        # Aplica DCT bidimensional (primero sobre filas, luego sobre columnas)
        dct_image = dct(dct(self.image_data.T, norm='ortho').T, norm='ortho')
        return dct_image


    def apply_idct(self, dct_image):
        """
        Aplica la inversa de la transformada discreta del coseno (IDCT) para reconstruir la imagen.
        """
        # Aplica la IDCT bidimensional
        idct_image = idct(idct(dct_image.T, norm='ortho').T, norm='ortho')
        return np.uint8(np.clip(idct_image, 0, 255))  # Asegura que los valores estén en el rango [0, 255]



class DWTProcessor:
    def __init__(self, image_data):
        """
        Constructor que recibe los datos de la imagen (como un array 2D).
        """
        self.image_data = image_data

    def apply_dwt(self):
        """
        Aplica la transformada discreta de wavelet (DWT) a los datos de la imagen.
        Devuelve los coeficientes de aproximación y detalle.
        """
        coeffs2 = pywt.dwt2(self.image_data, 'bior1.3')  # Usando wavelet biortogonal 1.3
        LL, (LH, HL, HH) = coeffs2  # Los 4 coeficientes: aproximación y 3 detalles
        return LL, LH, HL, HH

    def apply_idwt(self, LL, LH, HL, HH):
        """
        Aplica la inversa de la transformada discreta de wavelet (IDWT) para reconstruir la imagen.
        Asegura que los valores de los píxeles estén en el rango [0, 255].
        """
        reconstructed_image = pywt.idwt2((LL, (LH, HL, HH)), 'bior1.3')
        # Asegurarse de que los valores de los píxeles estén en el rango [0, 255]
        reconstructed_image = np.clip(reconstructed_image, 0, 255)
        return reconstructed_image


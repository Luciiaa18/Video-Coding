import math
import unittest
from PIL import Image

from fastapi.testclient import TestClient
from main import app, JPEGProcessor, ImageProcessor, CompressionUtils, DCTProcessor, DWTProcessor
import os
import numpy as np



client = TestClient(app)


class TestColorConverter(unittest.TestCase):

    def test_rgb_to_yuv(self):
        rgb = (100, 150, 200)
        expected_yuv = (140.75, 29.16, -35.75)

        response = client.post("/convert_rgb_to_yuv", json={"r": rgb[0], "g": rgb[1], "b": rgb[2]})

        self.assertEqual(response.status_code, 200)
        result = response.json()

        self.assertAlmostEqual(round(result["Y"], 1), round(expected_yuv[0], 1))
        self.assertAlmostEqual(round(result["U"], 1), round(expected_yuv[1], 1))
        self.assertAlmostEqual(round(result["V"], 1), round(expected_yuv[2], 1))

    def test_yuv_to_rgb(self):
        yuv = (140.75, 29.16, -35.75)
        expected_rgb = (100, 150, 200)

        response = client.post("/convert_yuv_to_rgb", json={"y": yuv[0], "u": yuv[1], "v": yuv[2]})

        self.assertEqual(response.status_code, 200)
        result = response.json()

        self.assertAlmostEqual(round(result["R"], 1), round(expected_rgb[0], 1))
        self.assertAlmostEqual(round(result["G"], 1), round(expected_rgb[1], 1))
        self.assertAlmostEqual(round(result["B"], 1), round(expected_rgb[2], 1))


class TestImageCompression(unittest.TestCase):
    def test_image_compression(self):
        input_image = 'photo.jpg'
        output_image = 'photo_compressed.jpg'

        # Usamos FFmpeg para comprimir la imagen
        os.system(f'ffmpeg -i {input_image} -q:v 10 {output_image} > nul 2>&1')

        # Verificamos que el archivo comprimido exista
        self.assertTrue(os.path.exists(output_image), "Comprimido: El archivo no se ha creado")

        # Comprobamos el tamaño del archivo original y comprimido
        original_size = os.path.getsize(input_image)
        compressed_size = os.path.getsize(output_image)

        print(f"Tamaño original: {original_size} bytes")
        print(f"Tamaño comprimido: {compressed_size} bytes")

        # Comprobamos que el tamaño comprimido sea menor que el original
        self.assertLess(compressed_size, original_size, "El archivo comprimido es más grande que el original")

        # Limpiar el archivo comprimido después de la prueba
        os.remove(output_image)


class TestJPEGProcessor(unittest.TestCase):

    def test_serpentine(self):
        # Definir el archivo de entrada JPEG
        file_path = 'photo.jpg'  # Cambia esto a la ruta de tu imagen JPEG

        serpentine_bytes = JPEGProcessor.serpentine(file_path)

        # Verificar que se ha leído alguna cantidad de bytes
        self.assertGreater(len(serpentine_bytes), 0, "No se han leído bytes del archivo JPEG.")


        # Verificar que el patrón serpentino tiene la longitud correcta
        # Por ejemplo, verificamos si la longitud es la misma que la longitud del archivo dividido por 16 (simulando filas de 16 bytes)
        with open(file_path, 'rb') as file:
            file_data = file.read()
            expected_length = len(file_data)
            self.assertEqual(len(serpentine_bytes), expected_length, "La longitud de los bytes en patrón serpentino no coincide con la longitud esperada.")


class TestImageProcessor(unittest.TestCase):

    def test_compress_to_bw(self):
        # Definir las rutas de entrada y salida
        input_file = 'photo.jpg'  # Cambia esto a la ruta de tu imagen
        output_file = 'photo_bw_compressed.jpg'
        compression_level = 10  # Nivel de compresión (ajústalo según sea necesario)


        # Ejecutar la conversión a blanco y negro con compresión
        ImageProcessor.compress_to_bw(input_file, output_file, compression_level)


        # Verificar que el archivo de salida se haya creado
        self.assertTrue(os.path.exists(output_file), "El archivo comprimido no fue creado.")


        # Verificar que la imagen convertida y comprimida tiene un tamaño razonable
        original_size = os.path.getsize(input_file)
        compressed_size = os.path.getsize(output_file)
        self.assertLess(compressed_size, original_size, "El archivo comprimido debería ser más pequeño que el archivo original.")


        # Limpiar el archivo de salida después de la prueba
        os.remove(output_file)


class TestCompressionUtils(unittest.TestCase):

    def test_run_length_encoding(self):
        # Caso 1: Secuencia simple
        byte_sequence = [1, 1, 2, 2, 2, 3, 3, 1]
        expected_output = [(1, 2), (2, 3), (3, 2), (1, 1)]
        result = CompressionUtils.run_length_encoding(byte_sequence)
        self.assertEqual(result, expected_output)

        # Caso 2: Secuencia con un solo valor
        byte_sequence = [5, 5, 5, 5]
        expected_output = [(5, 4)]
        result = CompressionUtils.run_length_encoding(byte_sequence)
        self.assertEqual(result, expected_output)

        # Caso 3: Secuencia con todos valores diferentes
        byte_sequence = [1, 2, 3, 4, 5]
        expected_output = [(1, 1), (2, 1), (3, 1), (4, 1), (5, 1)]
        result = CompressionUtils.run_length_encoding(byte_sequence)
        self.assertEqual(result, expected_output)

        # Caso 4: Secuencia vacía
        byte_sequence = []
        expected_output = []
        result = CompressionUtils.run_length_encoding(byte_sequence)
        self.assertEqual(result, expected_output)



class TestDCTProcessor(unittest.TestCase):

    def setUp(self):
        """
        Configuración inicial para las pruebas. Carga una imagen de prueba y la convierte en escala de grises.
        """
        image_path = 'photo_bw_auto.jpg'
        img = Image.open(image_path).convert('L')
        self.image_data = np.array(img)
        self.dct_processor = DCTProcessor(self.image_data)


    def test_dct(self):
        """
        Verifica que la DCT se aplique correctamente.
        La imagen transformada no debe ser igual a la original.
        """
        dct_image = self.dct_processor.apply_dct()
        # Aseguramos que los coeficientes de DCT no sean iguales a la imagen original
        self.assertFalse(np.array_equal(dct_image, self.image_data), "La DCT no se aplicó correctamente")


    def test_idct(self):
        """
        Verifica que la IDCT reconstruya la imagen correctamente.
        La imagen reconstruida debe ser lo más parecida posible a la original.
        """
        dct_image = self.dct_processor.apply_dct()
        reconstructed_image = self.dct_processor.apply_idct(dct_image)
        # Comprobamos que la imagen reconstruida sea parecida a la original
        self.assertTrue(np.allclose(self.image_data, reconstructed_image, atol=1), "La imagen reconstruida no coincide con la original")


    def test_pixel_range(self):
        """
        Verifica que los valores de píxel en la imagen reconstruida estén dentro del rango [0, 255].
        """
        dct_image = self.dct_processor.apply_dct()
        reconstructed_image = self.dct_processor.apply_idct(dct_image)
        # Comprobamos que los valores de la imagen reconstruida estén dentro del rango [0, 255]
        self.assertTrue(np.all((reconstructed_image >= 0) & (reconstructed_image <= 255)), "Los valores de los píxeles están fuera del rango [0, 255]")


class TestDWTProcessor(unittest.TestCase):

    def setUp(self):
        """
        Configuración inicial para las pruebas. Carga una imagen de prueba y la convierte en escala de grises.
        """
        image_path = 'photo_bw_auto.jpg'
        img = Image.open(image_path).convert('L')  # Convierte a escala de grises
        self.image_data = np.array(img)  # Convierte la imagen a un array de numpy
        self.dwt_processor = DWTProcessor(self.image_data)  # Instancia el procesador de DWT

    def test_dwt(self):
        """
        Verifica que la DWT se aplique correctamente.
        La imagen transformada no debe ser igual a la original.
        """
        LL, LH, HL, HH = self.dwt_processor.apply_dwt()
        # Comprobamos que los coeficientes de DWT no sean iguales a la imagen original
        self.assertFalse(np.array_equal(LL, self.image_data), "Los coeficientes de DWT no son correctos")
        self.assertFalse(np.array_equal(LH, self.image_data), "Los coeficientes de DWT no son correctos")
        self.assertFalse(np.array_equal(HL, self.image_data), "Los coeficientes de DWT no son correctos")
        self.assertFalse(np.array_equal(HH, self.image_data), "Los coeficientes de DWT no son correctos")

    def test_idwt(self):
        """
        Verifica que la IDWT reconstruya la imagen correctamente.
        La imagen reconstruida debe ser lo más parecida posible a la original.
        """
        LL, LH, HL, HH = self.dwt_processor.apply_dwt()
        reconstructed_image = self.dwt_processor.apply_idwt(LL, LH, HL, HH)
        # Comprobamos que la imagen reconstruida sea parecida a la original
        self.assertTrue(np.allclose(self.image_data, reconstructed_image, atol=1), "La imagen reconstruida no coincide con la original")

    def test_pixel_range(self):
        """
        Verifica que los valores de píxel en la imagen reconstruida estén dentro del rango [0, 255].
        """
        LL, LH, HL, HH = self.dwt_processor.apply_dwt()
        reconstructed_image = self.dwt_processor.apply_idwt(LL, LH, HL, HH)
        # Comprobamos que los valores de la imagen reconstruida estén dentro del rango [0, 255]
        self.assertTrue(np.all((reconstructed_image >= 0) & (reconstructed_image <= 255)), "Los valores de los píxeles están fuera del rango [0, 255]")


if __name__ == "__main__":
    unittest.TextTestRunner(verbosity=2).run(unittest.TestLoader().loadTestsFromModule(__import__("test_main")))


